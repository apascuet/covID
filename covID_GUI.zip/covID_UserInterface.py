# -*- coding: utf-8 -*-
"""
Created on Sat Jun 13 21:41:00 2020

@author: andre
"""

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QApplication, QWidget, QInputDialog, QLineEdit, QFileDialog
from PyQt5.QtGui import QIcon, QPixmap
import cv2
import numpy as np
from matplotlib import pyplot as plt
from skimage.morphology import area_opening
from skimage.morphology import area_closing
from skimage.restoration import wiener
from skimage import color, data, restoration
from scipy.signal import convolve2d
from shutil import copyfile
from skimage.transform import resize
from keras.models import load_model
import tensorflow
import keras
from numpy.fft import fft2, ifft2
from scipy.signal import gaussian, convolve2d

from Help import Ui_Help

aux_global = None
COVID = None
NONCOVID = None
COVIDPRED = None
NONCOVIDPRED = None


SAVE_PATH='/Users/andre/Desktop/TryImages/GUI/Workspace.png'
APPLY_PATH='/Users/andre/Desktop/TryImages/GUI/Apply.png'
# ATTENTION: a model must be pretrained and the weights must be added hereunder:
MODEL_PATH='/Users/andre/Desktop/TryImages/GUI/CNN_original_weights_bo.h5'


# =============================================================================
#         CNN ARCHITECTURE
# =============================================================================

model = tensorflow.keras.models.Sequential()

# First layer: convlutional layer (extract features from the input image)
model.add(tensorflow.keras.layers.Conv2D(64, (5, 5), activation='relu', input_shape=(64,64,3)))

# Second layer: pooling layer with a 2x2 pixel filter
model.add(tensorflow.keras.layers.MaxPooling2D(pool_size=(2, 2)))

# Third layer: convolution layer and pooling layer
model.add(tensorflow.keras.layers.Conv2D(128, (5, 5), activation='relu'))
model.add(tensorflow.keras.layers.MaxPooling2D(pool_size=(2, 2)))

# Forth layer: flattening layer (reduce image to linear array)
model.add(tensorflow.keras.layers.Flatten())

# Neural network: first layer has 1000 neurons and the activation function ReLu
model.add(tensorflow.keras.layers.Dense(1000, activation='relu'))

# Fifth layer: drop out of 50%
model.add(tensorflow.keras.layers.Dropout(0.5))

model.add(tensorflow.keras.layers.Dense(500, activation='relu'))

model.add(tensorflow.keras.layers.Dropout(0.5))

# Neural network: first layer has 250 neurons and the activation function ReLu
model.add(tensorflow.keras.layers.Dense(250, activation='relu'))

# Last layer of this neural network with 10 neurons (one for each label) using the softmax function
model.add(tensorflow.keras.layers.Dense(2, activation='softmax'))

# COMPILE THE MODEL
# categorical_crossentropy: for classes greater thatn 2?

model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])


# load model
model.load_weights(MODEL_PATH)
# summarize model.
model.summary()

# =============================================================================
#         GUI
# =============================================================================


# =============================================================================
#         Global functions used in wiener filter
# =============================================================================
def wiener_filter(img, kernel, K):
	kernel /= np.sum(kernel)
	dummy = np.copy(img)
	dummy = fft2(dummy)
	kernel = fft2(kernel, s = img.shape)
	kernel = np.conj(kernel) / (np.abs(kernel) ** 2 + K)
	dummy = dummy * kernel
	dummy = np.abs(ifft2(dummy))
	return dummy

def gaussian_kernel(kernel_size = 3):
	h = gaussian(kernel_size, kernel_size / 3).reshape(kernel_size, 1)
	h = np.dot(h, h.transpose())
	h /= np.sum(h)
	return h



# =============================================================================
# DIALOG INFO PATIENTS
# =============================================================================
class Ui_Results(object):
    
    
    def setupUi(self, Results):
        Results.setObjectName("Results")
        Results.resize(400, 148)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("check.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        Results.setWindowIcon(icon)
        Results.setStyleSheet("background-color: rgb(255, 255, 255);")
        self.prediction_label = QtWidgets.QLabel(Results)
        self.prediction_label.setGeometry(QtCore.QRect(50, 30, 281, 81))
        font = QtGui.QFont()
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        self.prediction_label.setFont(font)
        self.prediction_label.setStyleSheet("background-image: url(:/logollarg/logollarg.jpg);")
        self.prediction_label.setText("")
        self.prediction_label.setAlignment(QtCore.Qt.AlignCenter)
        self.prediction_label.setWordWrap(True)
        self.prediction_label.setObjectName("prediction_label")

        self.retranslateUi(Results)
        QtCore.QMetaObject.connectSlotsByName(Results)

    def retranslateUi(self, Results):
        _translate = QtCore.QCoreApplication.translate
        Results.setWindowTitle(_translate("Results", "covID Results"))
        global aux_global
        if aux_global == 1:
            self.final_text_predict='COVID-19 probability: '+str(round(COVIDPRED*100,3))+'; \nNon-COVID-19 probability: '+str(round(NONCOVIDPRED*100,3))
            self.prediction_label.setText(self.final_text_predict)
            aux_global = None
        else:
            self.final_text_predict='COVID-19 probability: '+str(round(COVID*100,3))+'; \nNon-COVID-19 probability: '+str(round(NONCOVID*100,3))
            self.prediction_label.setText(self.final_text_predict)
            
import images
        
        
class Ui_Dialog(object):

    def open_info_patients(self):
        
        self.window=QtWidgets.QDialog()
        self.ui=Ui_info_patients_ui()
        self.ui.setupUi(self.window)
        self.window.show()
        
    def open_question_Window2(self):
        global aux_global
        aux_global = 1                                                                                                         # NOU
        self.window=QtWidgets.QDialog()
        self.ui=Ui_Results()
        self.ui.setupUi(self.window)
        self.window.show()
        
    def reject(self):
        self.close()
        
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(350, 100)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("check.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        Dialog.setWindowIcon(icon)
        self.question_label = QtWidgets.QLabel(Dialog)
        self.question_label.setGeometry(QtCore.QRect(40, 10, 256, 21))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.question_label.setFont(font)
        self.question_label.setObjectName("question_label")
        self.widget = QtWidgets.QWidget(Dialog)
        self.widget.setGeometry(QtCore.QRect(50, 30, 229, 66))
        self.widget.setObjectName("widget")
        self.gridLayout = QtWidgets.QGridLayout(self.widget)
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.gridLayout.setObjectName("gridLayout")
        self.continue_button = QtWidgets.QPushButton(self.widget)
        self.continue_button.setStyleSheet("QPushButton {\n"
"    background-color: rgb(225, 225, 225);\n"
"    border-style: outset;\n"
"    border-width: 2px;\n"
"    border-radius: 10px;\n"
"    border-color: rgb(80, 80, 80);\n"
"    padding: 6px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgb(240, 240, 240);\n"
"    border-style: outset;\n"
"    border-width: 2px;\n"
"    border-radius: 10px;\n"
"    border-color: rgb(80, 80, 80);\n"
"    min-width: 10em;\n"
"    padding: 6px;\n"
"    }\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: rgb(235, 235, 235);\n"
"    border-style: outset;\n"
"    border-width: 2px;\n"
"    border-radius: 10px;\n"
"    border-color: rgb(80, 80, 80);\n"
"    min-width: 10em;\n"
"    padding: 6px;\n"
"    }")
        self.continue_button.setObjectName("continue_button")
        self.gridLayout.addWidget(self.continue_button, 0, 1, 1, 1)
        self.add_data_button = QtWidgets.QPushButton(self.widget)
        self.add_data_button.setStyleSheet("QPushButton {\n"
"    background-color: rgb(225, 225, 225);\n"
"    border-style: outset;\n"
"    border-width: 2px;\n"
"    border-radius: 10px;\n"
"    border-color: rgb(80, 80, 80);\n"
"    padding: 6px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgb(240, 240, 240);\n"
"    border-style: outset;\n"
"    border-width: 2px;\n"
"    border-radius: 10px;\n"
"    border-color: rgb(80, 80, 80);\n"
"    min-width: 10em;\n"
"    padding: 6px;\n"
"    }\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: rgb(235, 235, 235);\n"
"    border-style: outset;\n"
"    border-width: 2px;\n"
"    border-radius: 10px;\n"
"    border-color: rgb(80, 80, 80);\n"
"    min-width: 10em;\n"
"    padding: 6px;\n"
"    }")
        self.add_data_button.setObjectName("add_data_button")
        self.gridLayout.addWidget(self.add_data_button, 0, 0, 1, 1)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Patient extra information"))
        self.question_label.setText(_translate("Dialog", "<html><head/><body><p align=\"center\">Do you want to add medical data?</p></body></html>"))
        self.continue_button.setText(_translate("Dialog", "Continue (No)"))
        self.add_data_button.setText(_translate("Dialog", "Add medical data... (Yes)"))
        self.add_data_button.clicked.connect(Dialog.reject)
        self.add_data_button.clicked.connect(self.open_info_patients)
        self.continue_button.clicked.connect(Dialog.reject)
        self.continue_button.clicked.connect(self.open_question_Window2)
    


# =============================================================================
# INFO PATIENTS
# =============================================================================

class Ui_info_patients_ui(object):
        
    def setupUi(self, info_patients_ui):
        info_patients_ui.setObjectName("info_patients_ui")
        info_patients_ui.resize(400, 300)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("patientinfo.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        info_patients_ui.setWindowIcon(icon)
        self.question_label = QtWidgets.QLabel(info_patients_ui)
        self.question_label.setGeometry(QtCore.QRect(30, 10, 341, 20))
        self.question_label.setObjectName("question_label")
        self.info_patients = QtWidgets.QLabel(info_patients_ui)
        self.info_patients.setGeometry(QtCore.QRect(180, 50, 211, 171))
        self.info_patients.setObjectName("info_patients")
        self.layoutWidget = QtWidgets.QWidget(info_patients_ui)
        self.layoutWidget.setGeometry(QtCore.QRect(60, 30, 147, 65))
        self.layoutWidget.setObjectName("layoutWidget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.layoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.A = QtWidgets.QCheckBox(self.layoutWidget)
        self.A.setObjectName("A")
        self.verticalLayout.addWidget(self.A)
        self.B = QtWidgets.QCheckBox(self.layoutWidget)
        self.B.setObjectName("B")
        self.verticalLayout.addWidget(self.B)
        self.C = QtWidgets.QCheckBox(self.layoutWidget)
        self.C.setObjectName("C")
        self.verticalLayout.addWidget(self.C)
        self.layoutWidget1 = QtWidgets.QWidget(info_patients_ui)
        self.layoutWidget1.setGeometry(QtCore.QRect(200, 250, 171, 32))
        self.layoutWidget1.setObjectName("layoutWidget1")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.layoutWidget1)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.cancel_button = QtWidgets.QPushButton(self.layoutWidget1)
        self.cancel_button.setStyleSheet("QPushButton {\n"
"    background-color: rgb(225, 225, 225);\n"
"    border-style: outset;\n"
"    border-width: 2px;\n"
"    border-radius: 10px;\n"
"    border-color: rgb(80, 80, 80);\n"
"    padding: 6px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgb(240, 240, 240);\n"
"    border-style: outset;\n"
"    border-width: 2px;\n"
"    border-radius: 10px;\n"
"    border-color: rgb(80, 80, 80);\n"
"    min-width: 10em;\n"
"    padding: 6px;\n"
"    }\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: rgb(235, 235, 235);\n"
"    border-style: outset;\n"
"    border-width: 2px;\n"
"    border-radius: 10px;\n"
"    border-color: rgb(80, 80, 80);\n"
"    min-width: 10em;\n"
"    padding: 6px;\n"
"    }")
        self.cancel_button.setObjectName("cancel_button")
        self.horizontalLayout.addWidget(self.cancel_button)
        self.apply_button = QtWidgets.QPushButton(self.layoutWidget1)
        self.apply_button.setStyleSheet("QPushButton {\n"
"    background-color: rgb(225, 225, 225);\n"
"    border-style: outset;\n"
"    border-width: 2px;\n"
"    border-radius: 10px;\n"
"    border-color: rgb(80, 80, 80);\n"
"    padding: 6px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgb(240, 240, 240);\n"
"    border-style: outset;\n"
"    border-width: 2px;\n"
"    border-radius: 10px;\n"
"    border-color: rgb(80, 80, 80);\n"
"    min-width: 10em;\n"
"    padding: 6px;\n"
"    }\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: rgb(235, 235, 235);\n"
"    border-style: outset;\n"
"    border-width: 2px;\n"
"    border-radius: 10px;\n"
"    border-color: rgb(80, 80, 80);\n"
"    min-width: 10em;\n"
"    padding: 6px;\n"
"    }")
        self.apply_button.setObjectName("apply_button")
        self.horizontalLayout.addWidget(self.apply_button)
        self.question_label_2 = QtWidgets.QLabel(info_patients_ui)
        self.question_label_2.setGeometry(QtCore.QRect(30, 110, 341, 20))
        self.question_label_2.setObjectName("question_label_2")
        self.question_label_3 = QtWidgets.QLabel(info_patients_ui)
        self.question_label_3.setGeometry(QtCore.QRect(30, 190, 341, 20))
        self.question_label_3.setObjectName("question_label_3")
        self.layoutWidget_2 = QtWidgets.QWidget(info_patients_ui)
        self.layoutWidget_2.setGeometry(QtCore.QRect(60, 210, 84, 42))
        self.layoutWidget_2.setObjectName("layoutWidget_2")
        self.gridLayout_2 = QtWidgets.QGridLayout(self.layoutWidget_2)
        self.gridLayout_2.setContentsMargins(0, 0, 0, 0)
        self.gridLayout_2.setObjectName("gridLayout_2")
        self.radioButton_3 = QtWidgets.QRadioButton(self.layoutWidget_2)
        self.radioButton_3.setObjectName("radioButton_3")
        self.gridLayout_2.addWidget(self.radioButton_3, 2, 0, 1, 1)
        self.radioButton_4 = QtWidgets.QRadioButton(self.layoutWidget_2)
        self.radioButton_4.setObjectName("radioButton_4")
        self.gridLayout_2.addWidget(self.radioButton_4, 1, 0, 1, 1)
        self.widget = QtWidgets.QWidget(info_patients_ui)
        self.widget.setGeometry(QtCore.QRect(60, 130, 84, 42))
        self.widget.setObjectName("widget")
        self.gridLayout = QtWidgets.QGridLayout(self.widget)
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.gridLayout.setObjectName("gridLayout")
        self.radioButton_2 = QtWidgets.QRadioButton(self.widget)
        self.radioButton_2.setObjectName("radioButton_2")
        self.gridLayout.addWidget(self.radioButton_2, 2, 0, 1, 1)
        self.radioButton = QtWidgets.QRadioButton(self.widget)
        self.radioButton.setObjectName("radioButton")
        self.gridLayout.addWidget(self.radioButton, 1, 0, 1, 1)

        self.retranslateUi(info_patients_ui)
        QtCore.QMetaObject.connectSlotsByName(info_patients_ui)

    def retranslateUi(self, info_patients_ui):
        _translate = QtCore.QCoreApplication.translate
        info_patients_ui.setWindowTitle(_translate("info_patients_ui", "Patient extra information"))
        self.question_label.setText(_translate("info_patients_ui", "Select the symptoms that the patient presents"))
        self.info_patients.setText(_translate("info_patients_ui", "<html><head/><body><p align=\"justify\"><br/></p></body></html>"))
        self.A.setText(_translate("info_patients_ui", "Fever"))
        self.B.setText(_translate("info_patients_ui", "Dry cough"))
        self.C.setText(_translate("info_patients_ui", "Asthenia (fatigue)"))
        self.cancel_button.setText(_translate("info_patients_ui", "Cancel"))
        self.apply_button.setText(_translate("info_patients_ui", "Apply"))
        self.question_label_2.setText(_translate("info_patients_ui", "Does the patient have been in contact with infected people?"))
        self.question_label_3.setText(_translate("info_patients_ui", "Is the PCR COVID diagnosis test positive on the patient?"))
        self.radioButton_3.setText(_translate("info_patients_ui", "No"))
        self.radioButton_4.setText(_translate("info_patients_ui", "Yes"))
        self.radioButton_2.setText(_translate("info_patients_ui", "No"))
        self.radioButton.setText(_translate("info_patients_ui", "Yes"))
        self.cancel_button.clicked.connect(info_patients_ui.reject)
        self.cancel_button.clicked.connect(self.open_question_Window3)
        self.apply_button.clicked.connect(info_patients_ui.reject)
        self.apply_button.clicked.connect(self.variables)

    def variables(self):
        self.list_variables=[0,0,0,0,0,0,0]
        if self.A.isChecked()==True:
            self.list_variables[0]=1
        if self.B.isChecked()==True:
            self.list_variables[1]=1
        if self.C.isChecked()==True:
            self.list_variables[2]=1
        if self.radioButton.isChecked()==True:
            self.list_variables[3]=1
        if self.radioButton_2.isChecked()==True:
            self.list_variables[4]=1
        if self.radioButton_4.isChecked()==True:
            self.list_variables[5]=1
        if self.radioButton_3.isChecked()==True:
            self.list_variables[6]=1
        
        self.gain=0
        if self.list_variables[0]==1:
            self.gain=self.gain+0.10
        if self.list_variables[1]==1:
            self.gain=self.gain+0.06
        if self.list_variables[2]==1:
            self.gain=self.gain+0.04
        if self.list_variables[3]==1:
            self.gain=self.gain+0.10
        if self.list_variables[5]==1:
            self.gain=self.gain+0.2
            
        self.covid = COVIDPRED*(1+self.gain)
        self.noncovid = NONCOVIDPRED - (self.covid - COVIDPRED)
        global COVID
        COVID = self.covid
        global NONCOVID
        NONCOVID = self.noncovid
        self.open_question_Window2()
     
    def open_question_Window2(self):                                                                                                         # NOU
        self.window=QtWidgets.QDialog()
        self.ui=Ui_Results()
        self.ui.setupUi(self.window)
        self.window.show()
        
    def open_question_Window3(self):
        global aux_global
        aux_global = 1                                                                                                           # NOU
        self.window=QtWidgets.QDialog()
        self.ui=Ui_Results()
        self.ui.setupUi(self.window)
        self.window.show()
        


# =============================================================================
# MAIN WINDOW
# =============================================================================

class Ui_MainWindow(object):
    def __init__(self):
        Ui_info_patients_ui.__init__(self)
    
    def open_question_Window(self):                                                                                                         # NOU
        self.window=QtWidgets.QDialog()
        self.ui=Ui_Dialog()
        self.ui.setupUi(self.window)
        self.window.show()
        
    def open_help_Window(self):                                                                                                         # NOU
        self.window=QtWidgets.QDialog()
        self.ui=Ui_Help()
        self.ui.setupUi(self.window)
        self.window.show()
    
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1280, 704)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("logo_icon.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        MainWindow.setWindowIcon(icon)
        MainWindow.setStyleSheet("background-color: rgb(0, 0, 0);\n"
"background-color: qlineargradient(spread:pad, x1:0, y1:1, x2:1, y2:0, stop:0 rgba(0, 0, 0, 255), stop:1 rgba(45, 45, 45, 255));\n"
"background-color: rgb(45, 45, 45);\n"
"QTabBar::tab {\n"
"    color:black;\n"
"    }")
        MainWindow.setTabShape(QtWidgets.QTabWidget.Rounded)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.Load_CTButton = QtWidgets.QPushButton(self.centralwidget)
        self.Load_CTButton.setGeometry(QtCore.QRect(30, 460, 146, 31))
        palette = QtGui.QPalette()
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.WindowText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Window, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.WindowText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Window, brush)
        brush = QtGui.QBrush(QtGui.QColor(120, 120, 120))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.WindowText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(120, 120, 120))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Window, brush)
        self.Load_CTButton.setPalette(palette)
        self.Load_CTButton.setStyleSheet("QPushButton {\n"
"    background-color: rgb(45, 45, 45);\n"
"    border-style: outset;\n"
"    border-width: 2px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    min-width: 10em;\n"
"    padding: 6px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgb(141, 141, 141);\n"
"    border-style: outset;\n"
"    border-width: 2px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    min-width: 10em;\n"
"    padding: 6px;\n"
"    }\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: rgb(100, 100, 100);\n"
"    border-style: outset;\n"
"    border-width: 2px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    min-width: 10em;\n"
"    padding: 6px;\n"
"    }")
        self.Load_CTButton.setAutoDefault(False)
        self.Load_CTButton.setDefault(False)
        self.Load_CTButton.setFlat(False)
        self.Load_CTButton.setObjectName("Load_CTButton")
        self.done_button = QtWidgets.QPushButton(self.centralwidget)
        self.done_button.setGeometry(QtCore.QRect(730, 460, 81, 31))
        palette = QtGui.QPalette()
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Window, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Window, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(120, 120, 120))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Window, brush)
        self.done_button.setPalette(palette)
        self.done_button.setStyleSheet("QPushButton {\n"
"    background-color: rgb(45, 45, 45);\n"
"    border-style: outset;\n"
"    border-width: 2px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 6px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgb(141, 141, 141);\n"
"    border-style: outset;\n"
"    border-width: 2px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 6px;\n"
"    }\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: rgb(100, 100, 100);\n"
"    border-style: outset;\n"
"    border-width: 2px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 6px;\n"
"    }\n"
"")
        self.done_button.setObjectName("done_button")
        self.top_label_4 = QtWidgets.QLabel(self.centralwidget)
        self.top_label_4.setGeometry(QtCore.QRect(910, 20, 161, 21))
        self.top_label_4.setObjectName("top_label_4")
        self.top_label_1 = QtWidgets.QLabel(self.centralwidget)
        self.top_label_1.setGeometry(QtCore.QRect(200, 20, 151, 21))
        self.top_label_1.setObjectName("top_label_1")
        self.label_esquerra = QtWidgets.QLabel(self.centralwidget)
        self.label_esquerra.setGeometry(QtCore.QRect(30, 60, 501, 391))
        self.label_esquerra.setAutoFillBackground(False)
        self.label_esquerra.setStyleSheet("border-image: url(/Users/andre/Documents/covID/Interface/image_background.png) 0 0 0 0 stretch stretch;")
        self.label_esquerra.setText("")
        self.label_esquerra.setObjectName("label_esquerra")
        self.label_dreta = QtWidgets.QLabel(self.centralwidget)
        self.label_dreta.setGeometry(QtCore.QRect(730, 60, 501, 391))
        self.label_dreta.setStyleSheet("border-image: url(/Users/andre/Documents/covID/Interface/logo_background.png) 0 0 0 0 stretch stretch;")
        self.label_dreta.setText("")
        self.label_dreta.setObjectName("label_dreta")
        self.splitter = QtWidgets.QSplitter(self.centralwidget)
        self.splitter.setGeometry(QtCore.QRect(570, 180, 121, 131))
        self.splitter.setOrientation(QtCore.Qt.Vertical)
        self.splitter.setObjectName("splitter")
        self.apply_button = QtWidgets.QPushButton(self.splitter)
        palette = QtGui.QPalette()
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Window, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Window, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(120, 120, 120))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Window, brush)
        self.apply_button.setPalette(palette)
        self.apply_button.setStyleSheet("QPushButton {\n"
"    background-color: rgb(45, 45, 45);\n"
"    border-style: outset;\n"
"    border-width: 2px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 6px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgb(141, 141, 141);\n"
"    border-style: outset;\n"
"    border-width: 2px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    min-width: 10em;\n"
"    padding: 6px;\n"
"    }\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: rgb(100, 100, 100);\n"
"    border-style: outset;\n"
"    border-width: 2px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    min-width: 10em;\n"
"    padding: 6px;\n"
"    }")
        self.apply_button.setObjectName("apply_button")
        self.redo_button = QtWidgets.QPushButton(self.splitter)
        palette = QtGui.QPalette()
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Window, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Window, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(120, 120, 120))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Window, brush)
        self.redo_button.setPalette(palette)
        self.redo_button.setStyleSheet("QPushButton {\n"
"    background-color: rgb(45, 45, 45);\n"
"    border-style: outset;\n"
"    border-width: 2px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 6px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgb(141, 141, 141);\n"
"    border-style: outset;\n"
"    border-width: 2px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 6px;\n"
"    }\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: rgb(100, 100, 100);\n"
"    border-style: outset;\n"
"    border-width: 2px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 6px;\n"
"    }")
        self.redo_button.setObjectName("redo_button")
        self.clear_button = QtWidgets.QPushButton(self.splitter)
        palette = QtGui.QPalette()
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Window, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Window, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(120, 120, 120))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Window, brush)
        self.clear_button.setPalette(palette)
        self.clear_button.setStyleSheet("QPushButton {\n"
"    background-color: rgb(45, 45, 45);\n"
"    border-style: outset;\n"
"    border-width: 2px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 6px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgb(141, 141, 141);\n"
"    border-style: outset;\n"
"    border-width: 2px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 6px;\n"
"    }\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: rgb(100, 100, 100);\n"
"    border-style: outset;\n"
"    border-width: 2px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 6px;\n"
"    }")
        self.clear_button.setObjectName("clear_button")
        self.cnn_prediction_label = QtWidgets.QLabel(self.centralwidget)
        self.cnn_prediction_label.setGeometry(QtCore.QRect(820, 460, 411, 31))
        self.cnn_prediction_label.setText("")
        self.cnn_prediction_label.setObjectName("cnn_prediction_label")
        self.tabWidget = QtWidgets.QTabWidget(self.centralwidget)
        self.tabWidget.setGeometry(QtCore.QRect(30, 500, 421, 151))
        palette = QtGui.QPalette()
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.WindowText, brush)
        brush = QtGui.QBrush(QtGui.QColor(80, 80, 80))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Text, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(80, 80, 80))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(80, 80, 80))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Window, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.WindowText, brush)
        brush = QtGui.QBrush(QtGui.QColor(80, 80, 80))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Text, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(80, 80, 80))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(80, 80, 80))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Window, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.WindowText, brush)
        brush = QtGui.QBrush(QtGui.QColor(80, 80, 80))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Text, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(80, 80, 80))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(80, 80, 80))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Window, brush)
        self.tabWidget.setPalette(palette)
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.tabWidget.setFont(font)
        self.tabWidget.setStyleSheet("QTabWidget::pane {\n"
"  border: 1px solid rgb(70, 70, 70);\n"
"  top:-1px; \n"
"  background: rgb(60, 60, 60);\n"
"} \n"
"\n"
"QTabBar::tab {\n"
"  background: rgb(60, 60, 60); \n"
"  border: 1px solid rgb(70, 70, 70); \n"
"  padding: 5px;\n"
"} \n"
"\n"
"QTabBar::tab:selected { \n"
"  background: rgb(80, 80, 80); \n"
"  margin-bottom: -1px; \n"
"}\n"
"\n"
"QWidget {\n"
"    background: solid rgb(80, 80, 80);\n"
"    color: white\n"
"} ")
        self.tabWidget.setObjectName("tabWidget")
        self.tab_filters = QtWidgets.QWidget()
        self.tab_filters.setObjectName("tab_filters")
        self.button_gaussian = QtWidgets.QPushButton(self.tab_filters)
        self.button_gaussian.setGeometry(QtCore.QRect(10, 10, 146, 21))
        palette = QtGui.QPalette()
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.WindowText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Text, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Window, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.WindowText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Text, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Window, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.WindowText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Text, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Window, brush)
        self.button_gaussian.setPalette(palette)
        self.button_gaussian.setStyleSheet("QPushButton {\n"
"    background-color: rgb(45, 45, 45);\n"
"    border-style: outset;\n"
"    border-width: 1px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 4px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgb(141, 141, 141);\n"
"    border-style: outset;\n"
"    border-width: 1px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 4px;\n"
"    }\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: rgb(100, 100, 100);\n"
"    border-style: outset;\n"
"    border-width: 1px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 4px;\n"
"    }")
        self.button_gaussian.setObjectName("button_gaussian")
        self.button_average = QtWidgets.QPushButton(self.tab_filters)
        self.button_average.setGeometry(QtCore.QRect(10, 40, 146, 21))
        palette = QtGui.QPalette()
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.WindowText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Text, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Window, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.WindowText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Text, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Window, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.WindowText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Text, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Window, brush)
        self.button_average.setPalette(palette)
        self.button_average.setStyleSheet("QPushButton {\n"
"    background-color: rgb(45, 45, 45);\n"
"    border-style: outset;\n"
"    border-width: 1px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 4px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgb(141, 141, 141);\n"
"    border-style: outset;\n"
"    border-width: 1px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 4px;\n"
"    }\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: rgb(100, 100, 100);\n"
"    border-style: outset;\n"
"    border-width: 1px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 4px;\n"
"    }")
        self.button_average.setObjectName("button_average")
        self.button_wiener = QtWidgets.QPushButton(self.tab_filters)
        self.button_wiener.setGeometry(QtCore.QRect(10, 70, 146, 21))
        palette = QtGui.QPalette()
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.WindowText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Text, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Window, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.WindowText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Text, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Window, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.WindowText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Text, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(45, 45, 45))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Window, brush)
        self.button_wiener.setPalette(palette)
        self.button_wiener.setStyleSheet("QPushButton {\n"
"    background-color: rgb(45, 45, 45);\n"
"    border-style: outset;\n"
"    border-width: 1px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 4px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgb(141, 141, 141);\n"
"    border-style: outset;\n"
"    border-width: 1px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 4px;\n"
"    }\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: rgb(100, 100, 100);\n"
"    border-style: outset;\n"
"    border-width: 1px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 4px;\n"
"    }")
        self.button_wiener.setObjectName("button_wiener")
        self.layoutWidget = QtWidgets.QWidget(self.tab_filters)
        self.layoutWidget.setGeometry(QtCore.QRect(180, 30, 211, 43))
        self.layoutWidget.setObjectName("layoutWidget")
        self.gridLayout = QtWidgets.QGridLayout(self.layoutWidget)
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.gridLayout.setObjectName("gridLayout")
        self.label = QtWidgets.QLabel(self.layoutWidget)
        palette = QtGui.QPalette()
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.WindowText, brush)
        brush = QtGui.QBrush(QtGui.QColor(80, 80, 80))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Text, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(80, 80, 80))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(80, 80, 80))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Window, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.WindowText, brush)
        brush = QtGui.QBrush(QtGui.QColor(80, 80, 80))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Text, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(80, 80, 80))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(80, 80, 80))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Window, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.WindowText, brush)
        brush = QtGui.QBrush(QtGui.QColor(80, 80, 80))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Text, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(80, 80, 80))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(80, 80, 80))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Window, brush)
        self.label.setPalette(palette)
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 0, 0, 1, 2)
        self.horizontalSlider = QtWidgets.QSlider(self.layoutWidget)
        self.horizontalSlider.setStyleSheet("QSlider::groove:horizontal {\n"
"    border: 1px solid #999999;\n"
"    height: 5px; /* the groove expands to the size of the slider by default. by giving it a height, it has a fixed size */\n"
"    background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 rgb(255, 255, 255), stop:1 rgb(147, 147, 147));\n"
"    margin: 2px 0;\n"
"}\n"
"\n"
"QSlider::handle:horizontal {\n"
"    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #b4b4b4, stop:1 #8f8f8f);\n"
"    border: 1px solid #5c5c5c;\n"
"    width: 10px;\n"
"    margin: -4px 0; /* handle is placed by default on the contents rect of the groove. Expand outside the groove */\n"
"    border-radius: 3px;\n"
"}")
        self.horizontalSlider.setOrientation(QtCore.Qt.Horizontal)
        self.horizontalSlider.setObjectName("horizontalSlider")
        self.gridLayout.addWidget(self.horizontalSlider, 1, 0, 1, 1)
        self.spinBox = QtWidgets.QSpinBox(self.layoutWidget)
        palette = QtGui.QPalette()
        brush = QtGui.QBrush(QtGui.QColor(0, 0, 0))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.WindowText, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(0, 0, 0))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Text, brush)
        brush = QtGui.QBrush(QtGui.QColor(0, 0, 0))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Window, brush)
        brush = QtGui.QBrush(QtGui.QColor(0, 0, 0))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.WindowText, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(0, 0, 0))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Text, brush)
        brush = QtGui.QBrush(QtGui.QColor(0, 0, 0))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Window, brush)
        brush = QtGui.QBrush(QtGui.QColor(0, 0, 0))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.WindowText, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(0, 0, 0))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Text, brush)
        brush = QtGui.QBrush(QtGui.QColor(0, 0, 0))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Window, brush)
        self.spinBox.setPalette(palette)
        self.spinBox.setStyleSheet("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0)")
        self.spinBox.setButtonSymbols(QtWidgets.QAbstractSpinBox.UpDownArrows)
        self.spinBox.setObjectName("spinBox")
        self.gridLayout.addWidget(self.spinBox, 1, 1, 1, 1)
        self.tabWidget.addTab(self.tab_filters, "")
        self.tab_contrast = QtWidgets.QWidget()
        self.tab_contrast.setObjectName("tab_contrast")
        self.label_2 = QtWidgets.QLabel(self.tab_contrast)
        self.label_2.setGeometry(QtCore.QRect(10, 10, 261, 16))
        self.label_2.setObjectName("label_2")
        self.button_CLAHE = QtWidgets.QPushButton(self.tab_contrast)
        self.button_CLAHE.setGeometry(QtCore.QRect(320, 40, 91, 51))
        self.button_CLAHE.setStyleSheet("QPushButton {\n"
"    background-color: rgb(45, 45, 45);\n"
"    border-style: outset;\n"
"    border-width: 1px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 4px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgb(141, 141, 141);\n"
"    border-style: outset;\n"
"    border-width: 1px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 4px;\n"
"    }\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: rgb(100, 100, 100);\n"
"    border-style: outset;\n"
"    border-width: 1px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 4px;\n"
"    }")
        self.button_CLAHE.setObjectName("button_CLAHE")
        self.button_Negative = QtWidgets.QPushButton(self.tab_contrast)
        self.button_Negative.setGeometry(QtCore.QRect(320, 100, 91, 23))
        self.button_Negative.setStyleSheet("QPushButton {\n"
"    background-color: rgb(45, 45, 45);\n"
"    border-style: outset;\n"
"    border-width: 1px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 4px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgb(141, 141, 141);\n"
"    border-style: outset;\n"
"    border-width: 1px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 4px;\n"
"    }\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: rgb(100, 100, 100);\n"
"    border-style: outset;\n"
"    border-width: 1px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 4px;\n"
"    }")
        self.button_Negative.setObjectName("button_Negative")
        self.layoutWidget1 = QtWidgets.QWidget(self.tab_contrast)
        self.layoutWidget1.setGeometry(QtCore.QRect(30, 30, 281, 76))
        self.layoutWidget1.setObjectName("layoutWidget1")
        self.gridLayout_2 = QtWidgets.QGridLayout(self.layoutWidget1)
        self.gridLayout_2.setContentsMargins(0, 0, 0, 0)
        self.gridLayout_2.setObjectName("gridLayout_2")
        self.label_4 = QtWidgets.QLabel(self.layoutWidget1)
        self.label_4.setObjectName("label_4")
        self.gridLayout_2.addWidget(self.label_4, 3, 0, 1, 1)
        self.label_3 = QtWidgets.QLabel(self.layoutWidget1)
        self.label_3.setObjectName("label_3")
        self.gridLayout_2.addWidget(self.label_3, 0, 0, 1, 1)
        self.spinBox_TileSize = QtWidgets.QSpinBox(self.layoutWidget1)
        self.spinBox_TileSize.setStyleSheet("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0)")
        self.spinBox_TileSize.setObjectName("spinBox_TileSize")
        self.gridLayout_2.addWidget(self.spinBox_TileSize, 0, 2, 1, 1)
        self.horizontalSlider_TileSize = QtWidgets.QSlider(self.layoutWidget1)
        self.horizontalSlider_TileSize.setStyleSheet("QSlider::groove:horizontal {\n"
"    border: 1px solid #999999;\n"
"    height: 5px; /* the groove expands to the size of the slider by default. by giving it a height, it has a fixed size */\n"
"    background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 rgb(255, 255, 255), stop:1 rgb(147, 147, 147));\n"
"    margin: 2px 0;\n"
"}\n"
"\n"
"QSlider::handle:horizontal {\n"
"    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #b4b4b4, stop:1 #8f8f8f);\n"
"    border: 1px solid #5c5c5c;\n"
"    width: 10px;\n"
"    margin: -4px 0; /* handle is placed by default on the contents rect of the groove. Expand outside the groove */\n"
"    border-radius: 3px;\n"
"}")
        self.horizontalSlider_TileSize.setOrientation(QtCore.Qt.Horizontal)
        self.horizontalSlider_TileSize.setObjectName("horizontalSlider_TileSize")
        self.gridLayout_2.addWidget(self.horizontalSlider_TileSize, 0, 1, 1, 1)
        self.spinBox_ContrastLimit = QtWidgets.QSpinBox(self.layoutWidget1)
        self.spinBox_ContrastLimit.setStyleSheet("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0)")
        self.spinBox_ContrastLimit.setObjectName("spinBox_ContrastLimit")
        self.gridLayout_2.addWidget(self.spinBox_ContrastLimit, 3, 2, 1, 1)
        self.horizontalSlider_ContrastLimit = QtWidgets.QSlider(self.layoutWidget1)
        self.horizontalSlider_ContrastLimit.setStyleSheet("QSlider::groove:horizontal {\n"
"    border: 1px solid #999999;\n"
"    height: 5px; /* the groove expands to the size of the slider by default. by giving it a height, it has a fixed size */\n"
"    background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 rgb(255, 255, 255), stop:1 rgb(147, 147, 147));\n"
"    margin: 2px 0;\n"
"}\n"
"\n"
"QSlider::handle:horizontal {\n"
"    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #b4b4b4, stop:1 #8f8f8f);\n"
"    border: 1px solid #5c5c5c;\n"
"    width: 10px;\n"
"    margin: -4px 0; /* handle is placed by default on the contents rect of the groove. Expand outside the groove */\n"
"    border-radius: 3px;\n"
"}")
        self.horizontalSlider_ContrastLimit.setOrientation(QtCore.Qt.Horizontal)
        self.horizontalSlider_ContrastLimit.setObjectName("horizontalSlider_ContrastLimit")
        self.gridLayout_2.addWidget(self.horizontalSlider_ContrastLimit, 3, 1, 1, 1)
        self.tabWidget.addTab(self.tab_contrast, "")
        self.tab_thresholding = QtWidgets.QWidget()
        self.tab_thresholding.setObjectName("tab_thresholding")
        self.button_Threshold = QtWidgets.QPushButton(self.tab_thresholding)
        self.button_Threshold.setGeometry(QtCore.QRect(260, 90, 146, 23))
        self.button_Threshold.setStyleSheet("QPushButton {\n"
"    background-color: rgb(45, 45, 45);\n"
"    border-style: outset;\n"
"    border-width: 1px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 4px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgb(141, 141, 141);\n"
"    border-style: outset;\n"
"    border-width: 1px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 4px;\n"
"    }\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: rgb(100, 100, 100);\n"
"    border-style: outset;\n"
"    border-width: 1px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 4px;\n"
"    }")
        self.button_Threshold.setObjectName("button_Threshold")
        self.layoutWidget2 = QtWidgets.QWidget(self.tab_thresholding)
        self.layoutWidget2.setGeometry(QtCore.QRect(20, 10, 311, 71))
        self.layoutWidget2.setObjectName("layoutWidget2")
        self.gridLayout_3 = QtWidgets.QGridLayout(self.layoutWidget2)
        self.gridLayout_3.setContentsMargins(0, 0, 0, 0)
        self.gridLayout_3.setObjectName("gridLayout_3")
        self.spinBox_C = QtWidgets.QSpinBox(self.layoutWidget2)
        self.spinBox_C.setStyleSheet("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0)")
        self.spinBox_C.setObjectName("spinBox_C")
        self.gridLayout_3.addWidget(self.spinBox_C, 1, 2, 1, 1)
        self.label_5 = QtWidgets.QLabel(self.layoutWidget2)
        self.label_5.setObjectName("label_5")
        self.gridLayout_3.addWidget(self.label_5, 0, 0, 1, 1)
        self.label_6 = QtWidgets.QLabel(self.layoutWidget2)
        self.label_6.setObjectName("label_6")
        self.gridLayout_3.addWidget(self.label_6, 1, 0, 1, 1)
        self.horizontalSlider_C = QtWidgets.QSlider(self.layoutWidget2)
        self.horizontalSlider_C.setStyleSheet("QSlider::groove:horizontal {\n"
"    border: 1px solid #999999;\n"
"    height: 5px; /* the groove expands to the size of the slider by default. by giving it a height, it has a fixed size */\n"
"    background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 rgb(255, 255, 255), stop:1 rgb(147, 147, 147));\n"
"    margin: 2px 0;\n"
"}\n"
"\n"
"QSlider::handle:horizontal {\n"
"    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #b4b4b4, stop:1 #8f8f8f);\n"
"    border: 1px solid #5c5c5c;\n"
"    width: 10px;\n"
"    margin: -4px 0; /* handle is placed by default on the contents rect of the groove. Expand outside the groove */\n"
"    border-radius: 3px;\n"
"}")
        self.horizontalSlider_C.setOrientation(QtCore.Qt.Horizontal)
        self.horizontalSlider_C.setObjectName("horizontalSlider_C")
        self.gridLayout_3.addWidget(self.horizontalSlider_C, 1, 1, 1, 1)
        self.spinBox_neighsize = QtWidgets.QSpinBox(self.layoutWidget2)
        self.spinBox_neighsize.setStyleSheet("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0)")
        self.spinBox_neighsize.setObjectName("spinBox_neighsize")
        self.gridLayout_3.addWidget(self.spinBox_neighsize, 0, 2, 1, 1)
        self.horizontalSlider_neighsize = QtWidgets.QSlider(self.layoutWidget2)
        self.horizontalSlider_neighsize.setStyleSheet("QSlider::groove:horizontal {\n"
"    border: 1px solid #999999;\n"
"    height: 5px; /* the groove expands to the size of the slider by default. by giving it a height, it has a fixed size */\n"
"    background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 rgb(255, 255, 255), stop:1 rgb(147, 147, 147));\n"
"    margin: 2px 0;\n"
"}\n"
"\n"
"QSlider::handle:horizontal {\n"
"    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #b4b4b4, stop:1 #8f8f8f);\n"
"    border: 1px solid #5c5c5c;\n"
"    width: 10px;\n"
"    margin: -4px 0; /* handle is placed by default on the contents rect of the groove. Expand outside the groove */\n"
"    border-radius: 3px;\n"
"}")
        self.horizontalSlider_neighsize.setOrientation(QtCore.Qt.Horizontal)
        self.horizontalSlider_neighsize.setObjectName("horizontalSlider_neighsize")
        self.gridLayout_3.addWidget(self.horizontalSlider_neighsize, 0, 1, 1, 1)
        self.tabWidget.addTab(self.tab_thresholding, "")
        self.tab_morphop = QtWidgets.QWidget()
        self.tab_morphop.setObjectName("tab_morphop")
        self.label_7 = QtWidgets.QLabel(self.tab_morphop)
        self.label_7.setGeometry(QtCore.QRect(10, 10, 101, 16))
        self.label_7.setObjectName("label_7")
        self.radioButton_rectangle = QtWidgets.QRadioButton(self.tab_morphop)
        self.radioButton_rectangle.setGeometry(QtCore.QRect(30, 30, 82, 17))
        self.radioButton_rectangle.setObjectName("radioButton_rectangle")
        self.radioButton_elipse = QtWidgets.QRadioButton(self.tab_morphop)
        self.radioButton_elipse.setGeometry(QtCore.QRect(30, 50, 82, 17))
        self.radioButton_elipse.setObjectName("radioButton_elipse")
        self.radioButton_cross = QtWidgets.QRadioButton(self.tab_morphop)
        self.radioButton_cross.setGeometry(QtCore.QRect(30, 70, 82, 17))
        self.radioButton_cross.setObjectName("radioButton_cross")
        self.button_erode = QtWidgets.QPushButton(self.tab_morphop)
        self.button_erode.setGeometry(QtCore.QRect(220, 20, 146, 23))
        self.button_erode.setStyleSheet("QPushButton {\n"
"    background-color: rgb(45, 45, 45);\n"
"    border-style: outset;\n"
"    border-width: 1px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 4px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgb(141, 141, 141);\n"
"    border-style: outset;\n"
"    border-width: 1px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 4px;\n"
"    }\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: rgb(100, 100, 100);\n"
"    border-style: outset;\n"
"    border-width: 1px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 4px;\n"
"    }")
        self.button_erode.setObjectName("button_erode")
        self.button_dilate = QtWidgets.QPushButton(self.tab_morphop)
        self.button_dilate.setGeometry(QtCore.QRect(220, 50, 146, 23))
        self.button_dilate.setStyleSheet("QPushButton {\n"
"    background-color: rgb(45, 45, 45);\n"
"    border-style: outset;\n"
"    border-width: 1px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 4px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgb(141, 141, 141);\n"
"    border-style: outset;\n"
"    border-width: 1px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 4px;\n"
"    }\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: rgb(100, 100, 100);\n"
"    border-style: outset;\n"
"    border-width: 1px;\n"
"    border-radius: 10px;\n"
"    border-color: white;\n"
"    padding: 4px;\n"
"    }")
        self.button_dilate.setObjectName("button_dilate")
        self.layoutWidget3 = QtWidgets.QWidget(self.tab_morphop)
        self.layoutWidget3.setGeometry(QtCore.QRect(10, 100, 301, 24))
        self.layoutWidget3.setObjectName("layoutWidget3")
        self.gridLayout_4 = QtWidgets.QGridLayout(self.layoutWidget3)
        self.gridLayout_4.setContentsMargins(0, 0, 0, 0)
        self.gridLayout_4.setObjectName("gridLayout_4")
        self.label_8 = QtWidgets.QLabel(self.layoutWidget3)
        self.label_8.setObjectName("label_8")
        self.gridLayout_4.addWidget(self.label_8, 0, 0, 1, 1)
        self.horizontalSlider_2 = QtWidgets.QSlider(self.layoutWidget3)
        self.horizontalSlider_2.setStyleSheet("QSlider::groove:horizontal {\n"
"    border: 1px solid #999999;\n"
"    height: 5px; /* the groove expands to the size of the slider by default. by giving it a height, it has a fixed size */\n"
"    background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 rgb(255, 255, 255), stop:1 rgb(147, 147, 147));\n"
"    margin: 2px 0;\n"
"}\n"
"\n"
"QSlider::handle:horizontal {\n"
"    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #b4b4b4, stop:1 #8f8f8f);\n"
"    border: 1px solid #5c5c5c;\n"
"    width: 10px;\n"
"    margin: -4px 0; /* handle is placed by default on the contents rect of the groove. Expand outside the groove */\n"
"    border-radius: 3px;\n"
"}")
        self.horizontalSlider_2.setOrientation(QtCore.Qt.Horizontal)
        self.horizontalSlider_2.setObjectName("horizontalSlider_2")
        self.gridLayout_4.addWidget(self.horizontalSlider_2, 0, 1, 1, 1)
        self.spinBox_2 = QtWidgets.QSpinBox(self.layoutWidget3)
        self.spinBox_2.setStyleSheet("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0)")
        self.spinBox_2.setObjectName("spinBox_2")
        self.gridLayout_4.addWidget(self.spinBox_2, 0, 2, 1, 1)
        self.tabWidget.addTab(self.tab_morphop, "")
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)
        self.menuBar = QtWidgets.QMenuBar(MainWindow)
        self.menuBar.setGeometry(QtCore.QRect(0, 0, 1280, 18))
        palette = QtGui.QPalette()
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.WindowText, brush)
        brush = QtGui.QBrush(QtGui.QColor(55, 55, 55))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(55, 55, 55))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(55, 55, 55))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.Window, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Active, QtGui.QPalette.ToolTipText, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.WindowText, brush)
        brush = QtGui.QBrush(QtGui.QColor(55, 55, 55))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(55, 55, 55))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(55, 55, 55))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.Window, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Inactive, QtGui.QPalette.ToolTipText, brush)
        brush = QtGui.QBrush(QtGui.QColor(120, 120, 120))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.WindowText, brush)
        brush = QtGui.QBrush(QtGui.QColor(55, 55, 55))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Button, brush)
        brush = QtGui.QBrush(QtGui.QColor(120, 120, 120))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.ButtonText, brush)
        brush = QtGui.QBrush(QtGui.QColor(55, 55, 55))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Base, brush)
        brush = QtGui.QBrush(QtGui.QColor(55, 55, 55))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.Window, brush)
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QtGui.QPalette.Disabled, QtGui.QPalette.ToolTipText, brush)
        self.menuBar.setPalette(palette)
        self.menuBar.setStyleSheet("QMenuBar {\n"
"    background-color: rgb(55, 55, 55)\n"
"}\n"
"\n"
"QMenuBar::item {\n"
"    spacing: 20px; /* spacing between menu bar items */\n"
"    padding: 1px 15px;\n"
"    background: transparent;\n"
"    border-radius: 4px;\n"
"}\n"
"\n"
"QMenuBar::item:selected { /* when selected using mouse or keyboard */\n"
"    background: rgb(75, 75, 75);\n"
"}\n"
"\n"
"QMenuBar::item:pressed {\n"
"    background:  rgb(60, 60, 60);\n"
"}")
        self.menuBar.setObjectName("menuBar")
        self.menuFile = QtWidgets.QMenu(self.menuBar)
        self.menuFile.setStyleSheet("QMenu {\n"
"    background-color: rgb(100, 100, 100); /* sets background of the menu */\n"
"    border: 1px solid black;\n"
"}\n"
"\n"
"QMenu::item {\n"
"    /* sets background of menu item. set this to something non-transparent\n"
"        if you want menu color and menu item color to be different */\n"
"    background-color: transparent;\n"
"}\n"
"\n"
"QMenu::item:selected { /* when user selects item using mouse or keyboard */\n"
"    background-color: rgb(120, 120, 120);\n"
"}")
        self.menuFile.setObjectName("menuFile")
        self.menuEdit = QtWidgets.QMenu(self.menuBar)
        self.menuEdit.setStyleSheet("QMenu {\n"
"    background-color: rgb(100, 100, 100); /* sets background of the menu */\n"
"    border: 1px solid black;\n"
"}\n"
"\n"
"QMenu::item {\n"
"    /* sets background of menu item. set this to something non-transparent\n"
"        if you want menu color and menu item color to be different */\n"
"    background-color: transparent;\n"
"}\n"
"\n"
"QMenu::item:selected { /* when user selects item using mouse or keyboard */\n"
"    background-color: rgb(120, 120, 120);\n"
"}")
        self.menuEdit.setObjectName("menuEdit")
        self.menuHelp = QtWidgets.QMenu(self.menuBar)
        self.menuHelp.setStyleSheet("QMenu {\n"
"    background-color: rgb(100, 100, 100); /* sets background of the menu */\n"
"    border: 1px solid black;\n"
"}\n"
"\n"
"QMenu::item {\n"
"    /* sets background of menu item. set this to something non-transparent\n"
"        if you want menu color and menu item color to be different */\n"
"    background-color: transparent;\n"
"}\n"
"\n"
"QMenu::item:selected { /* when user selects item using mouse or keyboard */\n"
"    background-color: rgb(120, 120, 120);\n"
"}")
        self.menuHelp.setObjectName("menuHelp")
        MainWindow.setMenuBar(self.menuBar)
        self.toolBar = QtWidgets.QToolBar(MainWindow)
        self.toolBar.setObjectName("toolBar")
        MainWindow.addToolBar(QtCore.Qt.TopToolBarArea, self.toolBar)
        self.actionNew = QtWidgets.QAction(MainWindow)
        self.actionNew.setObjectName("actionNew")
        self.actionLoad_an_image = QtWidgets.QAction(MainWindow)
        self.actionLoad_an_image.setObjectName("actionLoad_an_image")
        self.actionSave_as = QtWidgets.QAction(MainWindow)
        self.actionSave_as.setObjectName("actionSave_as")
        self.actionClose = QtWidgets.QAction(MainWindow)
        self.actionClose.setObjectName("actionClose")
        self.actionCovID_Help = QtWidgets.QAction(MainWindow)
        self.actionCovID_Help.setObjectName("actionCovID_Help")
        self.actionSend_comments = QtWidgets.QAction(MainWindow)
        self.actionSend_comments.setObjectName("actionSend_comments")
        self.actionClear = QtWidgets.QAction(MainWindow)
        self.actionClear.setObjectName("actionClear")
        self.menuFile.addAction(self.actionNew)
        self.menuFile.addSeparator()
        self.menuFile.addAction(self.actionSave_as)
        self.menuFile.addSeparator()
        self.menuFile.addAction(self.actionClose)
        self.menuEdit.addAction(self.actionClear)
        self.menuHelp.addAction(self.actionCovID_Help)
        self.menuHelp.addSeparator()
        self.menuHelp.addAction(self.actionSend_comments)
        self.menuBar.addAction(self.menuFile.menuAction())
        self.menuBar.addAction(self.menuEdit.menuAction())
        self.menuBar.addAction(self.menuHelp.menuAction())

        self.retranslateUi(MainWindow)
        self.tabWidget.setCurrentIndex(3)
        self.actionClose.triggered.connect(MainWindow.close)
        self.clear_button.clicked.connect(self.label_esquerra.clear)
        self.clear_button.clicked.connect(self.label_dreta.clear)
        self.spinBox_TileSize.valueChanged['int'].connect(self.horizontalSlider_TileSize.setValue)
        self.spinBox_ContrastLimit.valueChanged['int'].connect(self.horizontalSlider_ContrastLimit.setValue)
        self.horizontalSlider_TileSize.valueChanged['int'].connect(self.spinBox_TileSize.setValue)
        self.horizontalSlider_ContrastLimit.valueChanged['int'].connect(self.spinBox_ContrastLimit.setValue)
        self.spinBox.valueChanged['int'].connect(self.horizontalSlider.setValue)
        self.horizontalSlider.valueChanged['int'].connect(self.spinBox.setValue)
        self.spinBox_2.valueChanged['int'].connect(self.horizontalSlider_2.setValue)
        self.horizontalSlider_neighsize.valueChanged['int'].connect(self.spinBox_neighsize.setValue)
        self.horizontalSlider_2.valueChanged['int'].connect(self.spinBox_2.setValue)
        self.spinBox_neighsize.valueChanged['int'].connect(self.horizontalSlider_neighsize.setValue)
        self.horizontalSlider_C.valueChanged['int'].connect(self.spinBox_C.setValue)
        self.spinBox_C.valueChanged['int'].connect(self.horizontalSlider_C.setValue)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "covID - Coronavirus disease Identifier"))
        self.Load_CTButton.setText(_translate("MainWindow", "Load CT image..."))
        self.done_button.setText(_translate("MainWindow", "Done"))
        self.top_label_4.setText(_translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt; font-weight:600; color:#ffffff;\">Final (to classify)</span></p></body></html>"))
        self.top_label_1.setText(_translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt; font-weight:600; color:#ffffff;\">Workspace</span></p></body></html>"))
        self.apply_button.setText(_translate("MainWindow", "Apply"))
        self.redo_button.setText(_translate("MainWindow", "Original"))
        self.clear_button.setText(_translate("MainWindow", "Clear"))
        self.button_gaussian.setText(_translate("MainWindow", "Gaussian"))
        self.button_average.setText(_translate("MainWindow", "Average"))
        self.button_wiener.setText(_translate("MainWindow", "Wiener"))
        self.label.setToolTip(_translate("MainWindow", "<html><head/><body><p align=\"center\"><br/></p></body></html>"))
        self.label.setText(_translate("MainWindow", "<html><head/><body><p align=\"center\">Kernel size</p></body></html>"))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_filters), _translate("MainWindow", "Filters"))
        self.label_2.setText(_translate("MainWindow", "Contrast Limited Adaptive Histogram Equalization"))
        self.button_CLAHE.setText(_translate("MainWindow", "CLAHE"))
        self.button_Negative.setText(_translate("MainWindow", "Negative"))
        self.label_4.setText(_translate("MainWindow", "Contrast limit"))
        self.label_3.setText(_translate("MainWindow", "Tile size"))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_contrast), _translate("MainWindow", "Contrast"))
        self.button_Threshold.setText(_translate("MainWindow", "Threshold"))
        self.label_5.setText(_translate("MainWindow", "Neighbours block size"))
        self.label_6.setText(_translate("MainWindow", "Adaptive C parameter"))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_thresholding), _translate("MainWindow", "Thresholding"))
        self.label_7.setText(_translate("MainWindow", "Structuring element"))
        self.radioButton_rectangle.setText(_translate("MainWindow", "Rectangle"))
        self.radioButton_elipse.setText(_translate("MainWindow", "Ellipse"))
        self.radioButton_cross.setText(_translate("MainWindow", "Cross"))
        self.button_erode.setText(_translate("MainWindow", "Erode"))
        self.button_dilate.setText(_translate("MainWindow", "Dilate"))
        self.label_8.setText(_translate("MainWindow", "Kernel size"))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_morphop), _translate("MainWindow", "Morphological operators"))
        self.menuFile.setTitle(_translate("MainWindow", "File"))
        self.menuEdit.setTitle(_translate("MainWindow", "Edit"))
        self.menuHelp.setTitle(_translate("MainWindow", "Help"))
        self.toolBar.setWindowTitle(_translate("MainWindow", "toolBar"))
        self.actionNew.setText(_translate("MainWindow", "New..."))
        self.actionNew.setShortcut(_translate("MainWindow", "Ctrl+N"))
        self.actionLoad_an_image.setText(_translate("MainWindow", "Load an image"))
        self.actionSave_as.setText(_translate("MainWindow", "Save image as..."))
        self.actionSave_as.setShortcut(_translate("MainWindow", "Ctrl+S"))
        self.actionClose.setText(_translate("MainWindow", "Close"))
        self.actionClose.setShortcut(_translate("MainWindow", "Ctrl+F4"))
        self.actionCovID_Help.setText(_translate("MainWindow", "CovID Help"))
        self.actionCovID_Help.setShortcut(_translate("MainWindow", "Ctrl+Shift+H"))
        self.actionSend_comments.setText(_translate("MainWindow", "Send comments"))
        self.actionClear.setText(_translate("MainWindow", "Clear"))
        self.actionClear.setShortcut(_translate("MainWindow", "Ctrl+Shift+C"))


# =============================================================================
#         Connect buttons with actions
# =============================================================================
        self.Load_CTButton.clicked.connect(self.open_dialog_box)
        self.actionNew.triggered.connect(self.open_dialog_box)
        self.apply_button.clicked.connect(self.left2right)
        self.menuHelp.triggered.connect(self.open_help_Window)
        self.button_gaussian.clicked.connect(self.apply_gaussian)
        self.actionSave_as.triggered.connect(self._save_as)
        
        self.actionClear.triggered.connect(self.label_esquerra.clear)
        self.actionClear.triggered.connect(self.label_dreta.clear)
        self.button_average.clicked.connect(self.apply_average)
        self.button_erode.clicked.connect(self.apply_erosion)
        self.button_dilate.clicked.connect(self.apply_dilation)
        self.button_CLAHE.clicked.connect(self.apply_CLAHE)
        self.button_Threshold.clicked.connect(self.apply_threshold)
        self.redo_button.clicked.connect(self.redo)
        self.save_path=SAVE_PATH
        self.apply_path=APPLY_PATH
        self.button_Negative.clicked.connect(self.apply_negative)
        self.done_button.clicked.connect(self.done)
        self.button_wiener.clicked.connect(self.apply_wiener)
        
    def open_dialog_box(self):
        self.filename=QFileDialog.getOpenFileName()
        self.initial_path=self.filename[0]
        self.path=self.filename[0]
        self.pixmap=QPixmap(self.path)
        self.label_esquerra.setPixmap(QPixmap(self.pixmap))
        self.label_esquerra.setScaledContents(True)
        self.label_dreta.setPixmap(QPixmap(self.pixmap))
        self.label_dreta.setScaledContents(True)
        copyfile(self.path, self.apply_path)
        
    def _save_as(self):
       self.savefiledir=QFileDialog.getSaveFileName()
       print(self.savefiledir[0])
       copyfile(self.path, self.savefiledir[0])
        
        
    def left2right(self):
        self.label_dreta.setPixmap(QPixmap(self.pixmap))
        self.label_dreta.setScaledContents(True)
        copyfile(self.path, self.apply_path)
        
    def redo(self):
        self.path=self.initial_path
        self.pixmap=QPixmap(self.path)
        self.label_esquerra.setPixmap(QPixmap(self.pixmap))
        self.label_esquerra.setScaledContents(True)
        
# =============================================================================
#         
# =============================================================================
        
    def filter_kernel_size_value(self):
        self.kernel_value=int(str(self.horizontalSlider.value()))
        if self.kernel_value==0 or self.kernel_value % 2==0:
            self.kernel_value=self.kernel_value+1
        return self.kernel_value
    

    def gaussian_filter(self):
        kernelsize=self.filter_kernel_size_value()
        image=cv2.imread(self.path,1)
        gaussian_image = cv2.GaussianBlur(image,(kernelsize,kernelsize),0)
        cv2.imwrite(self.save_path,gaussian_image)
        self.path=self.save_path
        self.pixmap=QPixmap(self.path)
        return self.path
    
    def apply_gaussian(self):
        path=self.gaussian_filter()
        pixmap=QPixmap(path)
        self.label_esquerra.setPixmap(QPixmap(pixmap))
        self.label_esquerra.setScaledContents(True)
        
    
    def average_filter(self):
        kernelsize=self.filter_kernel_size_value()
        image=cv2.imread(self.path,1)
        average_image = cv2.blur(image,(kernelsize,kernelsize))
        cv2.imwrite(self.save_path,average_image)
        self.path=self.save_path
        self.pixmap=QPixmap(self.path)
        return self.path
    
    def apply_average(self):
        path=self.average_filter()
        pixmap=QPixmap(path)
        self.label_esquerra.setPixmap(QPixmap(pixmap))
        self.label_esquerra.setScaledContents(True)
    
    
    # def wiener_filter(self):
        # return self.path
    
    # def apply_wiener(self):
        # path = self.wiener_filter()
        # pixmap = QPixmap(path)
        # self.label_esquerra.setPixmap(QPixmap(pixmap))
        # self.label_esquerra.setScaledContents(True)
        
# =============================================================================
#         
# =============================================================================
        
    def negative_filter(self):
        image = cv2.imread(self.path,0)
        negative_image = cv2.bitwise_not(image)
        cv2.imwrite(self.save_path,negative_image)
        self.path = self.save_path
        self.pixmap = QPixmap(self.path)
        return self.path
    
    def apply_negative(self):
        path = self.negative_filter()
        pixmap = QPixmap(path)
        self.label_esquerra.setPixmap(QPixmap(pixmap))
        self.label_esquerra.setScaledContents(True)
        
        
    def tilegridsize(self):
        if self.horizontalSlider_TileSize.value() == 0:
            self.tilegridsizevalue = 1
        else:
            self.tilegridsizevalue = self.horizontalSlider_TileSize.value()
        return self.tilegridsizevalue
    
    def CLAHE_filter(self):
        image = cv2.imread(self.path,0)
        clahe = cv2.createCLAHE(clipLimit = self.horizontalSlider_ContrastLimit.value(), tileGridSize = (self.tilegridsize(), self.tilegridsize())) 
        enhanced_image = clahe.apply(image)
        cv2.imwrite(self.save_path, enhanced_image)
        self.path = self.save_path
        self.pixmap = QPixmap(self.path)
        return self.path
    
    def apply_CLAHE(self):
        path=self.CLAHE_filter()
        pixmap=QPixmap(path)
        self.label_esquerra.setPixmap(QPixmap(pixmap))
        self.label_esquerra.setScaledContents(True)
        
# =============================================================================
#         
# =============================================================================
    
    def blocksize(self):
        if self.horizontalSlider_neighsize.value() == 0:
            self.blocksizevalue = 3
        else:
            self.blocksizevalue = self.horizontalSlider_neighsize.value()
        
        if self.blocksizevalue % 2 == 0:
            self.blocksizevalue = self.blocksizevalue + 1
        return self.blocksizevalue
        
    def C(self):
        if self.horizontalSlider_C.value() == 0:
            self.Cvalue = 1
        else:
            self.Cvalue = self.horizontalSlider_C.value()
        return self.Cvalue
        
    def threshold_filter(self):
        image = cv2.imread(self.path,0)
        thresholded_image = cv2.adaptiveThreshold(image,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,\
               cv2.THRESH_BINARY_INV,self.blocksize(),self.C())
        cv2.imwrite(self.save_path,thresholded_image)
        self.path = self.save_path
        self.pixmap = QPixmap(self.path)
        return self.path
    
    def apply_threshold(self):
        path=self.threshold_filter()
        pixmap=QPixmap(path)
        self.label_esquerra.setPixmap(QPixmap(pixmap))
        self.label_esquerra.setScaledContents(True)
        
# =============================================================================
#         
# =============================================================================

    def MO_kernel_size_value(self):
        self.kernel_value = int(str(self.horizontalSlider_2.value()))
        if self.kernel_value == 0 or self.kernel_value % 2 == 0:
            self.kernel_value = self.kernel_value + 1
        return self.kernel_value
    
    def structural_element(self):
        if self.radioButton_elipse == True:
            self.SE = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (self.MO_kernel_size_value(),self.MO_kernel_size_value()))
        elif self.radioButton_cross == True:
            self.SE = cv2.getStructuringElement(cv2.MORPH_CROSS, (self.MO_kernel_size_value(),self.MO_kernel_size_value()))
        else:
            self.SE = cv2.getStructuringElement(cv2.MORPH_RECT, (self.MO_kernel_size_value(),self.MO_kernel_size_value()))


    def erosion_filter(self):
        kernel = self.structural_element()
        image = cv2.imread(self.path, 1)
        erosion_image = cv2.erode(image, kernel, iterations = 1)
        cv2.imwrite(self.save_path, erosion_image)
        self.path = self.save_path
        self.pixmap = QPixmap(self.path)
        return self.path
    
    def apply_erosion(self):
        path=self.erosion_filter()
        pixmap=QPixmap(path)
        self.label_esquerra.setPixmap(QPixmap(pixmap))
        self.label_esquerra.setScaledContents(True) 
    
    
    def dilation_filter(self):
        kernel = self.structural_element()
        image = cv2.imread(self.path, 1)
        dilation_image = cv2.dilate(image, kernel, iterations = 1)
        cv2.imwrite(self.save_path, dilation_image)
        self.path = self.save_path
        self.pixmap = QPixmap(self.path)
        return self.path
    
    def apply_dilation(self):
        path=self.dilation_filter()
        pixmap=QPixmap(path)
        self.label_esquerra.setPixmap(QPixmap(pixmap))
        self.label_esquerra.setScaledContents(True)
        
    def wiener_filtering(self):
        kernel = gaussian_kernel(self.MO_kernel_size_value())
        image = cv2.imread(self.path, 0)
        wiener_image = wiener_filter(image, kernel, K = 5)
        cv2.imwrite(self.save_path, wiener_image)
        self.path = self.save_path
        self.pixmap = QPixmap(self.path)
        return self.path
    
    def apply_wiener(self):
        path=self.wiener_filtering()
        pixmap=QPixmap(path)
        self.label_esquerra.setPixmap(QPixmap(pixmap))
        self.label_esquerra.setScaledContents(True)
        
    

        
# =============================================================================
# 
# =============================================================================

    def done(self):
        final_image = cv2.imread(self.apply_path,1) #Read in the image (3, 14, 20)
        resized_image = resize(final_image, (64, 64, 3))
        self.open_question_Window()
        predictions = model.predict(np.array( [resized_image] ))
        self.covidperc=predictions[0][1]
        self.noncovidperc=predictions[0][0]
        global COVIDPRED
        COVIDPRED = self.covidperc=predictions[0][1]
        global NONCOVIDPRED
        NONCOVIDPRED = self.noncovidperc=predictions[0][0]
        
           

        

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())

